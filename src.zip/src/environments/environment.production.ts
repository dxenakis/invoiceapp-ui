export const environment = {
  production: true,
  apiUrl: 'https://api.myapp.com/api',
  logging: false
};
