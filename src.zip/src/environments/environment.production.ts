export const environment = {
  production: true,
  apiUrl: '',
  logging: false
};
